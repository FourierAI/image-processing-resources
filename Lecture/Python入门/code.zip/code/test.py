# import random as rd
# print(rd.random())

# import fib
# print(fib.fiber1(10))
# print(fib.fiber2(10))

from sklearn import *
linear_model()